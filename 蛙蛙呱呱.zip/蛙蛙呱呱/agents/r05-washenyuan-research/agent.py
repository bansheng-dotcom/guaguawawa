# -*- coding: utf-8 -*-
"""R05 蛙深远（战略研究官）——薄调度器。

子命令：
  manifest / demo / run --task <id> / contract / review / case / harness
  + 7 个技能子命令（research/industry/competitor/business/sizing/scenario/auto）

设计约定（对齐 r02/r03/r04/r07）：
- 技能只做确定性计算，无 LLM 调用；退出码：ok=true → 0，否则 1。
- run --task 走 agents/core/workspace.py 协议（runlog 写 ../workspace/runlog.jsonl）。
- R05 边界：只做研究呈现证据与选项，不替你拍板。
"""
from __future__ import annotations

# --- 运行时引导（META-001 Stage 3）：仓库根入 sys.path，修掉异构 cwd 下 ---
# --- `ModuleNotFoundError: No module named 'agents'` 的历史故障 ---
import os as _os
import sys as _sys
_REPO_ROOT = _os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
if _REPO_ROOT not in _sys.path:
    _sys.path.insert(0, _REPO_ROOT)


import argparse
import json
import os
import sys
from agents.shared.chat_cli import add_chat_parser, handle_chat
from typing import Any, Dict, List, Optional, Tuple

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)          # agents/
for _p in (_ROOT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from skills import SKILLS, SKILL_BY_NAME                          # noqa: E402
from skills import _common as c                                    # noqa: E402
import contracts                                                    # noqa: E402
import cases as cases_lib                                           # noqa: E402
import review as review_lib                                        # noqa: E402
import harness as harness_lib                                       # noqa: E402

from core import protocol, workspace                 # noqa: E402
from agents.shared import role_runtime  # REP-001 报告引擎

ws = workspace.Workspace(os.path.join(_ROOT, "workspace"))

ROLE = "r05"
DIRS = os.path.basename(_HERE)

# ---------------------------------------------------------------------------
# 意图路由（具体关键词靠前；大小写不敏感；命中即返回）
# 元组：(关键词组, skill, action, extra_args 默认值)
# ---------------------------------------------------------------------------
_INTENT_ROUTES: List[Tuple[Tuple[str, ...], str, str, Dict[str, str]]] = [
    (("证据台账", "研究台账", "来源登记", "evidence ledger", "claims ledger"),
     "research", "ledger", {}),
    (("研究报告", "引用覆盖", "研究汇报", "research report"),
     "research", "report", {}),
    (("行业地图", "产业链", "价值链", "行业扫描", "landscape"),
     "industry", "landscape", {}),
    (("市场集中度", "HHI", "CR4", "集中度", "concentration"),
     "industry", "concentration", {}),
    (("竞品矩阵", "功能对比", "feature matrix", "竞品对比"),
     "competitor", "matrix", {}),
    (("战斗卡", "对位卡", "battlecard", "竞品威胁"),
     "competitor", "battlecard", {}),
    (("商业画布", "九宫格", "business canvas", "商业模式"),
     "business", "canvas", {}),
    (("变现", "定价", "单位经济", "ltv", "monetize"),
     "business", "monetize", {}),
    (("市场规模", "TAM", "SAM", "SOM", "market sizing"),
     "sizing", "size", {}),
    (("敏感性", "关键驱动", "sensitivity"),
     "sizing", "sensitivity", {}),
    (("宏观分析", "PESTEL", "政策环境"),
     "scenario", "pestel", {}),
    (("事前尸检", "失效推演", "pre-mortem", "premortem"),
     "scenario", "premortem", {}),
    (("研究计划", "research plan", "调研计划"),
     "auto", "plan", {}),
    (("研究追踪", "运行追踪", "调研进度", "research track"),
     "auto", "track", {}),
]
_DEFAULT_ROUTE: Tuple[str, str, Dict[str, str]] = ("research", "ledger", {})


def route_intent(intent: str) -> Tuple[str, str, Dict[str, str]]:
    low = str(intent or "").lower()
    for keys, skill, action, extra in _INTENT_ROUTES:
        for k in keys:
            if k.lower() in low:
                return skill, action, extra
    return _DEFAULT_ROUTE[0], _DEFAULT_ROUTE[1], _DEFAULT_ROUTE[2]


# ---------------------------------------------------------------------------
# CLI 组装
# ---------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="agent.py", description="R05 蛙深远（战略研究官）")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("manifest", help="打印角色能力清单")
    sub.add_parser("demo", help="用真实示例跑一组代表性动作")

    rp = sub.add_parser("run", help="按 task 卡执行一次研究任务")
    rp.add_argument("--task", required=True, help="task id（workspace 协议）")

    cp = sub.add_parser("contract", help="技能契约登记表")
    csub = cp.add_subparsers(dest="ccmd", required=True)
    csub.add_parser("list", help="列出全部 skill/action")
    cvp = csub.add_parser("validate", help="校验输出是否符合契约")
    cvp.add_argument("--skill", required=True, choices=contracts.skill_names())
    cvp.add_argument("--action", required=True)
    cvp.add_argument("--output", required=True, help="result.json 路径")

    rvp = sub.add_parser("review", help="对抗评审（T7）：对研究产出本身再评审")
    rvp.add_argument("--packet", required=True, help="产出包 JSON（{skill,action,result}）")

    cap = sub.add_parser("case", help="案例库")
    cap.add_argument("case_id", nargs="?", default=None,
                     help="缺省=列出全部；给定 id=展示并校验")

    hp = sub.add_parser("harness", help="确定性验证器")
    hsub = hp.add_subparsers(dest="hcmd", required=True)
    hmp = hsub.add_parser("materials", help="研究物料门禁（BLOCKED 判定）")
    hmp.add_argument("--input", required=True)
    hvp = hsub.add_parser("verdict", help="研究产出结构门禁")
    hvp.add_argument("--input", required=True)
    hpp = hsub.add_parser("plan", help="研究计划门禁")
    hpp.add_argument("--input", required=True)
    hrp = hsub.add_parser("runlog", help="最近 n 条 runlog")
    hrp.add_argument("--n", type=int, default=5)

    for m in SKILLS:
        m.add_parser(sub)
    return ap


# ---------------------------------------------------------------------------
# manifest / demo
# ---------------------------------------------------------------------------
def make_manifest() -> Dict[str, Any]:
    skills = [{"name": m.NAME, "desc": m.DESC,
               "actions": [{"action": a, "help": h}
                           for a, h in m.ACTIONS.items()]}
              for m in SKILLS]
    from core import registry
    role = registry.by_id(ROLE)
    skills = [{"name": m.NAME, "skill": m.NAME, "desc": m.DESC, "description": m.DESC,
               "actions": [{"action": a, "help": h} for a, h in m.ACTIONS.items()]}
              for m in SKILLS]
    return {
        "role": role["id"], "dirs": DIRS, "name": "蛙深远（战略研究官）",
        "title": role["title"], "capabilities": role["capabilities"],
        "inputs": role["inputs"], "outputs": role["outputs"],
        "capability_status": {"default": "real", "reason": "本地确定性研究可执行", "external_actions": "simulated"},
        "desc": "战略研究：证据台账、行业扫描、竞品情报、商业模式、市场规模、"
                "情景推演、研究自动化。只呈现证据与选项，不替你拍板。",
        "skills": skills,
        "skill_count": len(SKILLS),
        "action_count": sum(len(m.ACTIONS) for m in SKILLS),
        "cases": [r["case_id"] for r in cases_lib.list_cases()],
        "contracts": [f"{s}/{a}" for s in contracts.skill_names()
                      for a in contracts.actions(s)],
        "boundary": {
            "in_scope": ["行业/市场/竞品研究", "市场规模测算", "情景推演",
                         "证据台账与研究报告"],
            "out_of_scope": ["数据分析结论（归 R06）", "正式财务/法律判断（归 R03）",
                             "替老板决策（只呈现证据与选项）"],
            "never": ["无源断言（claims 必须挂来源）", "替你拍板（决策权在老板）",
                      "结论文本含推测措辞"],
        },
        "intent_routes": [{"keys": list(k), "skill": s, "action": a}
                          for k, s, a, _ in _INTENT_ROUTES],
    }


def _run_demo() -> int:
    demo_specs = [
        ("research", "ledger", os.path.join(_HERE, "examples", "research_ledger.json"), {}),
        ("sizing", "size", os.path.join(_HERE, "examples", "sizing_size.json"), {}),
        ("scenario", "premortem", os.path.join(_HERE, "examples", "scenario_premortem.json"), {}),
    ]
    artifacts_dir = ws.artifact("r05-demo")
    os.makedirs(artifacts_dir, exist_ok=True)
    lines: List[str] = []
    ok_all = True
    for skill, action, path, extra in demo_specs:
        args = argparse.Namespace(cmd=skill, action=action, input=path, **extra)
        out = SKILL_BY_NAME[skill].run(args)
        ok_all = ok_all and bool(out.get("ok"))
        c.write_json(os.path.join(artifacts_dir, f"{skill}-{action}.json"), out)
        verdict = out.get("verdict") or ("ok" if out.get("ok") else "FAIL")
        lines.append(f"[demo] {skill} {action} → verdict={verdict} ok={out.get('ok')}")
    lines.append(f"[demo] 产物目录：{artifacts_dir}")
    print("\n".join(lines))
    return 0 if ok_all else 1


# ---------------------------------------------------------------------------
# run --task（workspace 协议）
# ---------------------------------------------------------------------------
def _first_input_file(inputs) -> Optional[str]:
    for p in inputs or []:
        s = getattr(p, "name", "")
        if s and os.path.isfile(str(s)):
            return str(s)
    return None


def _mkns(**kw) -> argparse.Namespace:
    return argparse.Namespace(**kw)


def run_task(task_id: str) -> int:
    task = ws.read_task(task_id)
    if task is None:
        print(f"[run] task 不存在：{task_id}", file=sys.stderr)
        return 1
    if task.owner != ROLE:
        print(f"[run] task.owner={task.owner!r} != r05：拒绝执行（越权）",
              file=sys.stderr)
        return 1

    ws.set_status(task_id, "running")
    ws.emit(protocol.Event.now(ROLE, "task_started", task_id))

    intent = str(task.intent or "")
    skill, action, extra = route_intent(intent)
    input_path = _first_input_file(task.inputs) or extra.get("input") or ""
    if not input_path or not os.path.isfile(input_path):
        ws.set_status(task_id, "failed")
        ws.emit(protocol.Event.now(ROLE, "task_failed", task_id,
                                   {"reason": "缺少输入文件"}))
        print("[run] 缺少输入文件", file=sys.stderr)
        return 1

    mod = SKILL_BY_NAME[skill]
    args = _mkns(action=action, input=input_path,
                 **{k: v for k, v in extra.items() if k != "input"})
    out = mod.run(args)
    ok = bool(out.get("ok"))

    out_dir = ws.artifact(f"run-{task_id}")
    os.makedirs(out_dir, exist_ok=True)
    result_path = os.path.join(out_dir, f"{skill}_{action}_result.json")
    c.write_json(result_path, out)
    ports = role_runtime.emit(
        role=ROLE, name="蛙深远", title="战略研究官", result=out,
        skill=skill, action=action, intent=intent, out_dir=out_dir, input_path=input_path,
        md_name="research_report")

    ws.update_task(task_id, {"outputs": [
        protocol.Port(f"run-{task_id}/{skill}_{action}_result.json", "data",
                      "application/json").to_dict(),
        *[protocol.Port(f"run-{task_id}/{p.name}", p.kind, p.media_type).to_dict()
          for p in ports],
    ], "status": "done" if ok else "failed"})
    ws.emit(protocol.Event.now(ROLE, "task_finished", task_id,
                               {"skill": skill, "action": action, "ok": ok}))
    ws.log_run(ROLE, {"skill": f"{skill}/{action}", "task_id": task_id,
                      "ok": ok, "verdict": out.get("verdict")})
    print(f"[run] task={task_id} 路由 {skill}/{action} → {'ok' if ok else 'FAIL'}")
    c.emit(out)
    return 0 if ok else 1


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main(argv: Optional[List[str]] = None) -> int:
    _meta = role_runtime.handle_meta_command(list(sys.argv[1:] if argv is None else argv), ROLE)
    if _meta is not None:
        return _meta

    args = build_parser().parse_args(argv)
    cmd = args.cmd
    if cmd == "manifest":
        c.emit(make_manifest())
        return 0
    if cmd == "demo":
        return _run_demo()
    if cmd == "run":
        return run_task(args.task)
    if cmd == "contract":
        if args.ccmd == "list":
            rows = [f"{s}/{a}" for s in contracts.skill_names()
                    for a in contracts.actions(s)]
            print(json.dumps(rows, ensure_ascii=False, indent=2))
            return 0
        data = json.load(open(args.output, encoding="utf-8"))
        v = contracts.validate_output(args.skill, args.action, data)
        print(json.dumps(v, ensure_ascii=False, indent=2))
        return 0 if v["ok"] else 1
    if cmd == "review":
        packet = json.load(open(args.packet, encoding="utf-8"))
        out = review_lib.review_packet(packet)
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0 if out["ok"] else 1
    if cmd == "case":
        if not args.case_id:
            print(json.dumps(cases_lib.list_cases(), ensure_ascii=False, indent=2))
            return 0
        try:
            case = cases_lib.load_case(args.case_id)
        except KeyError as exc:
            print(f"[case] {exc}", file=sys.stderr)
            return 1
        v = cases_lib.validate_case(args.case_id)
        print(json.dumps({"case": {k: case.get(k) for k in
                                   ("case_id", "display_name", "description",
                                    "default_question")},
                          "validate": v}, ensure_ascii=False, indent=2))
        return 0 if v["ok"] else 1
    if cmd == "harness":
        try:
            out = (harness_lib.validate_runlog(args.n) if args.hcmd == "runlog"
                   else harness_lib.run_validator(args.hcmd, args.input))
        except FileNotFoundError as e:
            out = {"ok": False, "error": f"input not found: {e.filename or e}"}
        except (KeyError, ValueError, TypeError) as e:
            out = {"ok": False, "error": f"{type(e).__name__}: {e}"}
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0 if out.get("ok") else 1
    m = SKILL_BY_NAME.get(cmd)
    if m is None:
        print(f"未知命令：{cmd}", file=sys.stderr)
        return 2
    try:
        out = m.run(args)
    except FileNotFoundError as e:
        out = {"ok": False, "checks": [],
               "error": f"input not found: {e.filename or e}"}
    except (KeyError, ValueError, TypeError) as e:
        out = {"ok": False, "checks": [], "error": f"{type(e).__name__}: {e}"}
    c.emit(out)
    ws.log_run(ROLE, {"skill": f"{m.NAME}/{args.action}", "ok": bool(out.get("ok")),
                      "verdict": out.get("verdict")})
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
