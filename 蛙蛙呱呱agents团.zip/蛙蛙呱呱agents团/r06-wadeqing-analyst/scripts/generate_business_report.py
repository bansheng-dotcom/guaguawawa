﻿import json
import os
from datetime import datetime

_AGENT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_REPO = os.path.dirname(_AGENT)
out_html_path = os.path.join(_REPO, "workspace", "artifacts", "Professional_Business_Report.html")

html_content = f"""
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>R06 商业级 A/B 实验决策报告</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; margin: 40px; color: #333; background-color: #f4f7f6; line-height: 1.6; }}
        .container {{ max-width: 1000px; margin: auto; }}
        h1 {{ color: #2c3e50; text-align: center; border-bottom: 3px solid #16a085; padding-bottom: 15px; text-transform: uppercase; letter-spacing: 1px; }}
        h2 {{ color: #2980b9; margin-top: 30px; border-bottom: 1px solid #bdc3c7; padding-bottom: 5px; }}
        h3 {{ color: #34495e; }}
        .card {{ background: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); padding: 25px; margin-bottom: 25px; }}
        
        .executive-summary {{ background: #e8f8f5; border-left: 6px solid #1abc9c; padding: 20px; font-size: 16px; margin-top: 20px; }}
        .executive-summary strong {{ color: #16a085; }}
        
        .metric-grid {{ display: flex; justify-content: space-between; text-align: center; margin-top: 25px; margin-bottom: 25px; gap: 15px; }}
        .metric-box {{ padding: 20px; border-radius: 8px; background: #ecf0f1; flex: 1; box-shadow: inset 0 2px 4px rgba(0,0,0,0.05); }}
        .metric-value {{ font-size: 28px; font-weight: bold; margin-top: 10px; }}
        .metric-title {{ font-size: 14px; color: #7f8c8d; text-transform: uppercase; font-weight: bold; letter-spacing: 0.5px; }}
        
        .table {{ width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 15px; }}
        .table th, .table td {{ border: 1px solid #dfe6e9; padding: 12px 15px; text-align: left; }}
        .table th {{ background-color: #34495e; color: white; font-weight: 500; }}
        .table tr:nth-child(even) {{ background-color: #f8f9fa; }}
        
        .alert-box {{ background: #fdf2e9; border-left: 6px solid #e67e22; padding: 20px; margin-top: 20px; }}
        .alert-box h4 {{ margin-top: 0; color: #d35400; }}
        
        .timeline {{ position: relative; max-width: 1200px; margin: 20px auto; padding-left: 20px; border-left: 3px solid #16a085; }}
        .timeline-item {{ padding: 10px 20px; position: relative; background: #fff; margin-bottom: 15px; border-radius: 6px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }}
        .timeline-item::before {{ content: ''; position: absolute; width: 15px; height: 15px; background: #16a085; left: -30px; top: 15px; border-radius: 50%; z-index: 1; }}
    </style>
</head>
<body>
<div class="container">
    <h1>🚀 商业级 A/B 实验分析与执行决策书</h1>
    <p style="text-align: center; color: #7f8c8d; font-size: 14px;">报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | 策略评估状态: <strong>[通过对抗性审查]</strong></p>

    <div class="card">
        <h2>1. 核心业务结论 (Executive Summary)</h2>
        <div class="executive-summary">
            <strong>最终决策结论：</strong>基于针对抖音渠道算法调整导致的转化率下滑归因（L2/L3诊断），系统自动触发了新旧素材A/B测试。数据表明新素材在统计学与业务层面均展现出显著优势。<br><br>
            <strong>行动指令：</strong>驳回“立即全量发布”的高风险草案，正式批准<strong>【分阶段灰度放量计划】</strong>，并严格执行配套的护栏熔断机制。
        </div>
        
        <div class="metric-grid">
            <div class="metric-box">
                <div class="metric-title">基准转化率 (Control)</div>
                <div class="metric-value" style="color:#2c3e50;">3.80%</div>
            </div>
            <div class="metric-box">
                <div class="metric-title">新版本转化率 (Treatment)</div>
                <div class="metric-value" style="color:#27ae60;">6.00%</div>
            </div>
            <div class="metric-title" style="flex: 1.5; display: flex; flex-direction: column; justify-content: center; align-items: center; background: #fff; border: 2px dashed #bdc3c7; border-radius: 8px;">
                <span style="font-size: 16px; color: #7f8c8d; margin-bottom: 5px;">提升幅度 (Lift)</span>
                <span style="font-size: 32px; font-weight: bold; color: #e74c3c;">+57.89%</span>
                <span style="font-size: 12px; color: #95a5a6; margin-top: 5px;">p-value: 0.0227 (显著)</span>
            </div>
        </div>
    </div>

    <div class="card">
        <h2>2. 实施计划：灰度放量时间表 (Rollout Strategy)</h2>
        <p>为规避小样本带来的“新奇效应(Novelty Effect)”和长期衰减风险，制定以下放量节奏：</p>
        <div class="timeline">
            <div class="timeline-item">
                <strong>Phase 1 (首日 0-24H): 5% 流量探测</strong><br>
                仅投放核心高潜人群，验证接口稳定性与加载速度，确保无致命缺陷。
            </div>
            <div class="timeline-item">
                <strong>Phase 2 (第2-3日): 20% 流量扩容</strong><br>
                引入泛流量群体，监测转化率是否发生断崖式衰减，评估长期留存趋势。
            </div>
            <div class="timeline-item">
                <strong>Phase 3 (第4日): 50% 核心切换</strong><br>
                若护栏指标全面绿灯，开启半数切换，对比系统级资源消耗。
            </div>
            <div class="timeline-item">
                <strong>Phase 4 (第7日): 100% 全量发布</strong><br>
                完成新素材渠道全面接管。
            </div>
        </div>
    </div>

    <div class="card alert-box">
        <h2>3. 风险控制：护栏红线指标 (Guardrails & Kill-switch)</h2>
        <p>在灰度期间，若触及以下任一阈值，必须<strong>自动熔断并回滚至旧素材 (Control)</strong>，无需二次审批：</p>
        <table class="table">
            <thead>
                <tr>
                    <th>监控维度</th>
                    <th>护栏指标名称</th>
                    <th>当前基线 (Base)</th>
                    <th>熔断红线 (Threshold)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>商业护栏</td>
                    <td>客单价 (AOV) 下滑度</td>
                    <td>￥ 128.5</td>
                    <td><strong>下降 > 3.0%</strong></td>
                </tr>
                <tr>
                    <td>服务护栏</td>
                    <td>退单率/客诉率</td>
                    <td>2.1%</td>
                    <td><strong>绝对值上升 > 1.0%</strong></td>
                </tr>
                <tr>
                    <td>技术护栏</td>
                    <td>素材首屏加载时间 (FCP)</td>
                    <td>1.2s</td>
                    <td><strong>耗时增加 > 200ms</strong></td>
                </tr>
            </tbody>
        </table>
    </div>

</div>
</body>
</html>
"""

with open(out_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

print(f"商业级 HTML 报告已生成: {out_html_path}")
